<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-6">
    <h1 class="text-3xl font-bold mb-6 text-gray-900 dark:text-white">Subir Archivos PDF</h1>

    <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
            <ul class="list-disc pl-5">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('archivos.store')); ?>" method="POST" enctype="multipart/form-data" class="mb-8 bg-white dark:bg-gray-800 p-6 rounded shadow-md">
        <?php echo csrf_field(); ?>

        <label for="cliente_id" class="block mb-2 font-semibold text-gray-900 dark:text-white">Selecciona Cliente</label>
        <select name="cliente_id" id="cliente_id" class="custom-select mb-4 w-full rounded border border-gray-300 p-2">
            <option value="">-- Selecciona un cliente --</option>
            <?php $__currentLoopData = App\Models\Cliente::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($cliente->id); ?>" <?php echo e(old('cliente_id') == $cliente->id ? 'selected' : ''); ?>>
                    <?php echo e($cliente->cedula); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <label for="pdf_file" class="block mb-2 font-semibold text-gray-900 dark:text-white">Selecciona archivo PDF</label>
        <input type="file" name="pdf_file" id="pdf_file" accept="application/pdf" class="custom-input mb-4 w-full rounded border border-gray-300 p-2">

        <button type="submit" class="custom-btn">Subir PDF</button>
    </form>

    <h2 class="text-2xl font-semibold mb-4 text-gray-900 dark:text-white">Archivos Subidos</h2>
    <table class="min-w-full bg-white dark:bg-gray-800 rounded shadow-md">
        <thead>
            <tr class="bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300">
                <th class="py-2 px-4 border-b border-gray-300 dark:border-gray-600">Cliente</th>
                <th class="py-2 px-4 border-b border-gray-300 dark:border-gray-600">Archivo PDF</th>
                <th class="py-2 px-4 border-b border-gray-300 dark:border-gray-600">Fecha de Subida</th>
                <th class="py-2 px-4 border-b border-gray-300 dark:border-gray-600">Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $archivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-gray-100 dark:hover:bg-gray-700">
                    <td class="py-2 px-4 border-b border-gray-300 dark:border-gray-600"><?php echo e($archivo->cliente->cedula); ?></td>
                    <td class="py-2 px-4 border-b border-gray-300 dark:border-gray-600">
                        <a href="<?php echo e(asset('storage/' . $archivo->filename)); ?>" target="_blank" class="text-blue-600 hover:underline">Ver PDF</a>
                    </td>
                    <td class="py-2 px-4 border-b border-gray-300 dark:border-gray-600"><?php echo e($archivo->created_at->format('d/m/Y H:i')); ?></td>
                    <td class="py-2 px-4 border-b border-gray-300 dark:border-gray-600">
                        <!-- Aquí puedes agregar botones para eliminar o descargar si quieres -->
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\agencia\proyecto-final\resources\views/archivos/index.blade.php ENDPATH**/ ?>